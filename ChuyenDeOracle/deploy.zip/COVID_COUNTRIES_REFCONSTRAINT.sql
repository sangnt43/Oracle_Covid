--------------------------------------------------------
--  Ref Constraints for Table COVID_COUNTRIES
--------------------------------------------------------

  ALTER TABLE "COVID_COUNTRIES" ADD CONSTRAINT "COVID_CONTRIES_FK1" FOREIGN KEY ("COUNTRY_ID")
	  REFERENCES "COUNTRIES" ("ID") ENABLE;
