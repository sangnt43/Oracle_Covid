--------------------------------------------------------
--  File created - Wednesday-June-24-2020   
--------------------------------------------------------
@COVID_COUNTRIES.sql
--@COVID_COUNTRIES_DATA_TABLE.csv
@COVID_COUNTRIES_PK.sql
@COVID_COUNTRIES_CONSTRAINT.sql
@COVID_COUNTRIES_REFCONSTRAINT.sql
